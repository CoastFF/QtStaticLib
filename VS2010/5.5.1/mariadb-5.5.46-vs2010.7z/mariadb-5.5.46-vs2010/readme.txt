 
26 Oct 2015
====================================================================================================================== 	
 url: http://www.npcglib.org/~stathis/blog/precompiled-mariadb 	
====================================================================================================================== 
These are the pre-built MariaDB Libraries v5.5.46. They are compiled with MS VC  
for 32/64-bit Windows, using Visual Studio 2010. 
 
----------------------------------------------------------------------- 
32-bit libraries in mariadb\lib 
64-bit libraries in mariadb64\lib 
 
Release shared libmysql.lib 
  Debug shared libmysqld.lib 
Release static mysqlclient.lib 
  Debug static mysqlclientd.lib 
----------------------------------------------------------------------- 
 
====================================================================================================================== 
If you have any comments or problems send me an email at: 
  stathis <stathis@npcglib.org> 
